const List mylist = [
  {"img": "assets/images/img_1.png"},
  {"img": "assets/images/img_2.png"},
  {"img": "assets/images/img_3.png"},
  {"img": "assets/images/img_4.png"},
];

const List popularList = [
  {"img": "assets/images/img_5.png"},
  {"img": "assets/images/img_6.png"},
  {"img": "assets/images/img_7.png"},
  {"img": "assets/images/img_8.png"},
];

const List trendingList = [
  {"img": "assets/images/img_9.png"},
  {"img": "assets/images/img_10.png"},
  {"img": "assets/images/img_11.png"},
  {"img": "assets/images/img_12.png"},
];

const List originalList = [
  {"img": "assets/images/img_13.png"},
  {"img": "assets/images/img_14.png"},
  {"img": "assets/images/img_15.png"},
];

const List animeList = [
  {"img": "assets/images/img_16.png"},
  {"img": "assets/images/img_17.png"},
  {"img": "assets/images/img_18.png"},
  {"img": "assets/images/img_19.png"},
];
