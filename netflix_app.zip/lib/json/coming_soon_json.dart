const List comingSoonJson = [
  {
    "img": "assets/images/banner.webp",
    "title_img": "assets/images/title_img.webp",
    "title": "Sentinelle",
    "description":
        "Considered a fool and unfit to lead, Nobunaga rises to power as the head of the Oda clan, spurring dissent among those in his family vying for control.",
    "type": "Gritty - Dark - Action Thriller - Action & Adventure - Drama",
    "date": "Coming Friday",
    "duration": true
  },
  {
    "img": "assets/images/banner_1.webp",
    "title_img": "assets/images/title_img_1.webp",
    "title": "Vincenzo",
    "description":
        "During a visit to his motherland, a Korean-Italian mafia lawyer gives an unrivaled conglomerate a taste of its own medicine with a side of justice.",
    "type": "Gritty - Dark - Action Thriller - Action & Adventure - Drama",
    "date": "New Episode Coming Saturday",
    "duration": false
  },
  {
    "img": "assets/images/banner_2.webp",
    "title_img": "assets/images/title_img_2.webp",
    "title": "Peaky Blinders",
    "description":
        "A notorious gang in 1919 Birmingham, England, is led by the fierce Tommy Shelby, a crime boss set on moving up in the world no matter the cost.",
    "type": "Violence, Sex, Nudity, Language, Substances",
    "date": "2021 June",
    "duration": false
  }
];
