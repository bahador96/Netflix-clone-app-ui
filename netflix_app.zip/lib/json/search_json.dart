const List searchJson = [
  {
    "img": "assets/images/search_1.jpg",
    "title": "Age of Samurai: Battle for Japan",
    "video": "assets/videos/video_1.mp4",
  },
  {
    "img": "assets/images/search_2.jpg",
    "title": "Aquaman",
    "video": "assets/videos/video_2.mp4",
  },
  {
    "img": "assets/images/search_3.jpg",
    "title": "Animals on the Loose: A You vs. Wild Movie",
    "video": "assets/videos/video_2.mp4",
  },
  {
    "img": "assets/images/search_4.jpg",
    "title": "Tribes of Europa",
    "video": "assets/videos/video_2.mp4",
  },
  {
    "img": "assets/images/search_5.jpg",
    "title": "The Yin-Yang Master: Dream Of Eternity",
    "video": "assets/videos/video_2.mp4",
  },
  {
    "img": "assets/images/search_6.jpg",
    "title": "Space Sweepers",
    "video": "assets/videos/video_2.mp4",
  },
  {
    "img": "assets/images/search_7.jpg",
    "title": "Fate: The Winx Saga",
    "video": "assets/videos/video_2.mp4",
  }
];
