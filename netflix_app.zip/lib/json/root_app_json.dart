import 'package:flutter/material.dart';

List items = [
  // {"icon": AntDesign.home, "text": "Home"},
  // {"icon": AntDesign.playcircleo, "text": "Coming Soon"},
  // {"icon": AntDesign.search1, "text": "Search"},
  // {"icon": AntDesign.download, "text": "Downloads"},
  {"icon": Icons.home, "text": "Home"},
  {"icon": Icons.play_circle_outline, "text": "Coming Soon"},
  {"icon": Icons.search, "text": "Search"},
  {"icon": Icons.download_rounded, "text": "Downloads"},
];
